/**
*
* Script de perfil
*
* @author Emprezaz
*
**/
(function($, PATH, Helpers){

    $( function() {
        $('.draggable').draggable();
    } );
})($, PATH, Helpers);